let str = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
let simb = ['-', '+', '*', '@', '(', '&', '^', '%', '$', '#', '!', '', '`', '~', '', '<', '>', ';', ]
let numb = [1, 2, 3, 4, 5, 6, 7, 8, 9]

let = ms = []

ms = ms.concat(str)
ms = ms.concat(simb)
ms = ms.concat(numb) //присоедениеие массивов к ооднму общему

let newStr = str[Math.floor(Math.random() * str.length)] //случайна буква
let newSimb = simb[Math.floor(Math.random() * simb.length)] //случайный символ
let newNumb = numb[Math.floor(Math.random() * numb.length)] //случайная цифра 




let rnd = ms.sort(() => Math.random() - 0.5); // перемешка суммирования массива


rnd.length = Math.floor(Math.random() * (30 - 8) + 8) //количество сисволов в парое

let masJoin = rnd.join('') //объединенеи символов о одну строку


document.write(masJoin)