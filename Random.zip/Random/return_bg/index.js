const imgs = [

    '#DCDCDC',
    '#FAF0E6',
    '#FAEBD7',
    '#FFF8DC',
    '#F0FFFF',
    '#FFE4E1',
    '#2F4F4F',
    '#BEBEBE',
    '#483D8B',
    '#1E90FF',
    '#DB7093',
    '#FF6347',
    '#E9967A',
    '#CD853F',
    '#FAFAD2',
]

let box = document.querySelector('.two')


function show() {
    let a = Math.floor(Math.random() * imgs.length)
    let img = imgs[a]
    box.style.background = img
}

setInterval(show, 1000)


let one = document.querySelector('.one')